const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, GetCommand, PutCommand, ScanCommand, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");

const client = new DynamoDBClient({ region: "ap-southeast-1" });
const docClient = DynamoDBDocumentClient.from(client);
const s3Client = new S3Client({ region: "ap-southeast-1" });

const USERS_TABLE = process.env.USERS_TABLE;
const UPLOAD_BUCKET = process.env.UPLOAD_BUCKET;
const ASSETS_DOMAIN = 'assets.bigfootws.com';

function transformAvatarUrl(url) {
    if (!url) return url;
    if (url.includes('amazonaws.com')) {
        return url.replace(`${UPLOAD_BUCKET}.s3.ap-southeast-1.amazonaws.com`, ASSETS_DOMAIN);
    }
    return url;
}

// ... async function uploadToS3 ... (omitted for brevity as not used in suspend)
async function uploadToS3(base64Data, userId) {
    const base64Image = base64Data.replace(/^data:image\/\w+;base64,/, "");
    const buffer = Buffer.from(base64Image, 'base64');
    const key = `avatars/${userId}.jpg`;

    await s3Client.send(new PutObjectCommand({
        Bucket: UPLOAD_BUCKET,
        Key: key,
        Body: buffer,
        ContentType: 'image/jpeg'
    }));

    return `https://${ASSETS_DOMAIN}/${key}`;
}

exports.handler = async (event) => {

    let _callerUserId = null;
    if (event.requestContext && event.requestContext.authorizer && event.requestContext.authorizer.claims) {
        _callerUserId = event.requestContext.authorizer.claims.sub || event.requestContext.authorizer.claims['cognito:username'];
    }
    if (!_callerUserId && event.headers) {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            try {
                const payloadBase64 = authHeader.split('.')[1];
                if (payloadBase64) {
                    const payload = JSON.parse(Buffer.from(payloadBase64, 'base64').toString());
                    _callerUserId = payload.sub || payload['cognito:username'] || payload.username;
                }
            } catch (e) {}
        }
    }
    if (!_callerUserId && event.queryStringParameters && event.queryStringParameters.userId) {
        _callerUserId = event.queryStringParameters.userId;
    }
    if (!_callerUserId && event.pathParameters && event.pathParameters.id) {
        if (event.resource && event.resource.includes('/profile/{id}')) {
             _callerUserId = event.pathParameters.id;
        } else if (event.path && event.path.includes('/profile/')) {
             _callerUserId = event.pathParameters.id;
        }
    }
    if (!_callerUserId && event.body) {
        try {
            const bodyObj = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
            if (bodyObj && bodyObj.userId) {
                _callerUserId = bodyObj.userId;
            }
        } catch (e) {}
    }

    if (_callerUserId) {
        try {
            const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
            const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');
            const _tmpClient = new DynamoDBClient({ region: 'ap-southeast-1' });
            const _docClient = DynamoDBDocumentClient.from(_tmpClient);
            const userTable = process.env.USERS_TABLE || 'BearJetsoUsers';
            const userRes = await _docClient.send(new GetCommand({
                TableName: userTable,
                Key: { userId: _callerUserId }
            }));
            if (userRes.Item && userRes.Item.suspended === true) {
                return {
                    statusCode: 200,
                    headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        status: 'suspended', 
                        message: '您的帳戶已被封鎖 / Your account has been blocked.', 
                        error: 'USER_BLOCKED' 
                    })
                };
            }
        } catch(e) { console.error('Block check error:', e); }
    }

    console.log("Incoming event:", JSON.stringify(event));
    const { httpMethod, path, pathParameters, body } = event;
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Content-Type": "application/json"
    };

    try {
        // GET /profile/{userId}
        if (httpMethod === 'GET' && pathParameters && pathParameters.id && path.includes('/profile')) {
            const userId = pathParameters.id;
            const data = await docClient.send(new GetCommand({
                TableName: USERS_TABLE,
                Key: { userId }
            }));

            if (!data.Item) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ message: "User not found" })
                };
            }

            const item = {
                ...data.Item,
                avatar: transformAvatarUrl(data.Item.avatar)
            };

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify(item)
            };
        }

        // POST /profile - Create or update profile
        if (httpMethod === 'POST' && (!path || path === '/profile')) {
            const userData = JSON.parse(body);
            const { userId, avatarData, ...rest } = userData;
            if (!userId) {
                return { statusCode: 400, headers, body: JSON.stringify({ message: "userId is required" }) };
            }

            let avatarUrl = userData.avatar;
            if (avatarData) {
                console.log(`Attempting S3 upload for user ${userId}, data length: ${avatarData.length}`);
                try {
                    avatarUrl = await uploadToS3(avatarData, userId);
                    console.log(`S3 upload success: ${avatarUrl}`);
                } catch (s3Error) {
                    console.error("S3 Upload Error:", s3Error);
                }
            }

            const item = {
                ...rest,
                userId,
                avatar: transformAvatarUrl(avatarUrl),
                updatedAt: Date.now()
            };

            console.log(`Saving to DynamoDB: ${userId}`);
            await docClient.send(new PutCommand({
                TableName: USERS_TABLE,
                Item: item
            }));
            console.log("DynamoDB save success");

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify(item)
            };
        }

        // DEBUG: Return env vars in body if hitting specific path
        if (httpMethod === 'POST' && path && path.includes('/suspend')) {
            const userId = pathParameters ? pathParameters.id : null;
            if (!userId) {
                return { statusCode: 400, headers, body: JSON.stringify({ message: "userId is required" }) };
            }
            const bodyData = JSON.parse(body || '{}');
            const suspended = bodyData.suspended !== false;

            console.log(`Updating user ${userId} to suspended=${suspended} in table ${USERS_TABLE}`);

            const res = await docClient.send(new UpdateCommand({
                TableName: USERS_TABLE,
                Key: { userId },
                UpdateExpression: "SET suspended = :s, updatedAt = :now",
                ExpressionAttributeValues: {
                    ":s": suspended,
                    ":now": Date.now()
                },
                ReturnValues: "ALL_NEW"
            }));

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    suspended: res.Attributes.suspended,
                    debug: {
                        table: USERS_TABLE,
                        userId: userId,
                        region: process.env.AWS_REGION
                    }
                })
            };
        }

        // Re-implement GET /admin/users for backward compatibility check
        if (httpMethod === 'GET' && path && (path.endsWith('/admin/users') || path.endsWith('/users'))) {
            const data = await docClient.send(new ScanCommand({
                TableName: USERS_TABLE
            }));
            const items = (data.Items || []).map(item => ({
                ...item,
                avatar: transformAvatarUrl(item.avatar)
            }));
            return { statusCode: 200, headers, body: JSON.stringify(items) };
        }

        return { statusCode: 404, headers, body: JSON.stringify({ message: "Not Found", path }) };

    } catch (error) {
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ message: error.message, stack: error.stack })
        };
    }
};
